"""
Logging utility for MT5 to Tastytrade copy trading system.
"""
import logging
import os
from datetime import datetime
from config import COPY_TRADING_CONFIG

class CopyTradingLogger:
    """Custom logger for copy trading operations."""
    
    def __init__(self, name="copy_trading"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, COPY_TRADING_CONFIG['log_level']))
        
        # Create logs directory if it doesn't exist
        os.makedirs('logs', exist_ok=True)
        
        # File handler
        file_handler = logging.FileHandler(
            f'logs/copy_trading_{datetime.now().strftime("%Y%m%d")}.log'
        )
        file_handler.setLevel(logging.DEBUG)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers if they don't exist
        if not self.logger.handlers:
            self.logger.addHandler(file_handler)
            self.logger.addHandler(console_handler)
    
    def info(self, message):
        """Log info message."""
        self.logger.info(message)
    
    def error(self, message):
        """Log error message."""
        self.logger.error(message)
    
    def warning(self, message):
        """Log warning message."""
        self.logger.warning(message)
    
    def debug(self, message):
        """Log debug message."""
        self.logger.debug(message)
    
    def critical(self, message):
        """Log critical message."""
        self.logger.critical(message)
    
    def log_trade_detected(self, mt5_trade):
        """Log when a new MT5 trade is detected."""
        self.info(f"New MT5 trade detected: {mt5_trade}")
    
    def log_trade_copied(self, mt5_trade, tasty_order):
        """Log when a trade is successfully copied to Tastytrade."""
        self.info(f"Trade copied to Tastytrade - MT5: {mt5_trade}, Tasty: {tasty_order}")
    
    def log_copy_error(self, mt5_trade, error):
        """Log when copying a trade fails."""
        self.error(f"Failed to copy trade {mt5_trade}: {error}")
    
    def log_connection_status(self, platform, status, details=""):
        """Log connection status for MT5 or Tastytrade."""
        self.info(f"{platform} connection: {status} {details}")
    
    def log_system_start(self):
        """Log system startup."""
        self.info("=== Copy Trading System Started ===")
    
    def log_system_stop(self):
        """Log system shutdown."""
        self.info("=== Copy Trading System Stopped ===")

# Global logger instance
logger = CopyTradingLogger()
