"""
Configuration file for MT5 to Tastytrade copy trading system.
"""
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# MT5 Configuration
MT5_CONFIG = {
    'login': int(os.getenv('MT5_LOGIN', '0')),
    'password': os.getenv('MT5_PASSWORD', ''),
    'server': os.getenv('MT5_SERVER', ''),
    'timeout': int(os.getenv('MT5_TIMEOUT', '60000')),
    'terminal_path': os.getenv('MT5_TERMINAL_PATH', r'C:\Program Files\MetaTrader 5\terminal64.exe'),
}

# Tastytrade Configuration
TASTY_CONFIG = {
    'username': os.getenv('TASTY_USERNAME', ''),
    'password': os.getenv('TASTY_PASSWORD', ''),
    'is_test': os.getenv('TASTY_IS_TEST', 'True').lower() == 'true',
}

# Copy Trading Configuration
COPY_TRADING_CONFIG = {
    'polling_interval': int(os.getenv('POLLING_INTERVAL', '2')),  # seconds
    'max_retries': int(os.getenv('MAX_RETRIES', '3')),
    'retry_delay': int(os.getenv('RETRY_DELAY', '5')),  # seconds
    'enable_logging': os.getenv('ENABLE_LOGGING', 'True').lower() == 'true',
    'log_level': os.getenv('LOG_LEVEL', 'INFO'),
}

# Symbol mapping (MT5 symbol -> Tastytrade symbol)
# Add custom mappings here if symbols differ between platforms
SYMBOL_MAPPING = {
    # Example: 'EURUSD' -> 'EUR/USD' if needed
    # For now, assuming same symbol names
}
