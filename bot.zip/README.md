# MT5 to Tastytrade Copy Trading System

A production-ready Python system that automatically copies trades from MetaTrader 5 (MT5) to Tastytrade. When a new trade is executed in MT5, the exact same trade is automatically placed in Tastytrade.

## Features

- **Real-time Monitoring**: Continuously monitors MT5 for new trades every 2 seconds
- **Automatic Copy Trading**: Automatically places equivalent orders in Tastytrade
- **Symbol Mapping**: Maps MT5 symbols to Tastytrade symbols (configurable)
- **Order Type Mapping**: Converts MT5 Buy/Sell to Tastytrade BUY_TO_OPEN/SELL_TO_OPEN
- **Volume Conversion**: Converts MT5 lot sizes to Tastytrade share quantities
- **Health Monitoring**: Automatic reconnection and health checks
- **Comprehensive Logging**: Detailed logs for all operations and errors
- **Graceful Shutdown**: Handles interrupts and cleanup properly

## Requirements

- Python 3.8+
- MetaTrader 5 terminal running
- Tastytrade account (live or sandbox)
- Internet connection

## Installation

1. **Clone or download the project files**

2. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure credentials**:
   - Copy `env_example.txt` to `.env`
   - Fill in your MT5 and Tastytrade credentials
   ```bash
   cp env_example.txt .env
   ```

4. **Edit `.env` file with your credentials**:
   ```env
   # MT5 Configuration
   MT5_LOGIN=12345
   MT5_PASSWORD=your_mt5_password
   MT5_SERVER=your_mt5_server
   MT5_TIMEOUT=60000

   # Tastytrade Configuration
   TASTY_USERNAME=your_tasty_username
   TASTY_PASSWORD=your_tasty_password
   TASTY_IS_TEST=True

   # Copy Trading Configuration
   POLLING_INTERVAL=2
   MAX_RETRIES=3
   RETRY_DELAY=5
   ENABLE_LOGGING=True
   LOG_LEVEL=INFO
   ```

## Usage

### Basic Usage

1. **Ensure MT5 terminal is running and logged in**

2. **Start the copy trading system**:
   ```bash
   python main.py
   ```

3. **Monitor the output** - the system will:
   - Connect to both MT5 and Tastytrade
   - Start monitoring for new trades
   - Log all activities to console and log files

4. **Stop the system** with `Ctrl+C` for graceful shutdown

### Configuration Options

- **POLLING_INTERVAL**: How often to check for new trades (default: 2 seconds)
- **MAX_RETRIES**: Maximum reconnection attempts (default: 3)
- **RETRY_DELAY**: Delay between retry attempts (default: 5 seconds)
- **LOG_LEVEL**: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)

## Project Structure

```
├── main.py              # Main orchestrator script
├── mt5_client.py        # MT5 connection and trade monitoring
├── tasty_client.py      # Tastytrade API client
├── config.py            # Configuration management
├── utils/
│   └── logger.py        # Logging utilities
├── requirements.txt      # Python dependencies
├── env_example.txt      # Environment variables template
└── README.md            # This file
```

## How It Works

1. **Connection Phase**:
   - Connects to MT5 terminal using login credentials
   - Connects to Tastytrade API (sandbox or live)

2. **Monitoring Phase**:
   - Polls MT5 every 2 seconds for new trades
   - Tracks processed trades to avoid duplicates

3. **Copy Trading Phase**:
   - When new MT5 trade detected, validates the trade
   - Maps MT5 symbol and order type to Tastytrade equivalents
   - Converts lot size to share quantity
   - Places market order in Tastytrade

4. **Health Monitoring**:
   - Continuously checks connection health
   - Automatically reconnects if connections are lost
   - Logs all activities and errors

## Symbol and Order Mapping

### Symbol Mapping
- By default, assumes same symbol names in both platforms
- Can be customized in `config.py` under `SYMBOL_MAPPING`

### Order Type Mapping
- MT5 BUY → Tastytrade BUY_TO_OPEN
- MT5 SELL → Tastytrade SELL_TO_OPEN

### Volume Conversion
- MT5 volume (lots) → Tastytrade quantity (shares)
- Default conversion: 1 lot = 100 shares
- Can be customized based on symbol contract sizes

## Logging

The system creates detailed logs in the `logs/` directory:
- Daily log files with timestamps
- Console output for real-time monitoring
- Different log levels (DEBUG, INFO, WARNING, ERROR, CRITICAL)

## Error Handling

- **Connection Failures**: Automatic reconnection with exponential backoff
- **API Errors**: Graceful error handling with detailed logging
- **Invalid Trades**: Validation and skipping of malformed trades
- **Network Issues**: Retry mechanisms and health checks

## Security Notes

- **Never commit your `.env` file** to version control
- **Use sandbox mode** for testing before going live
- **Monitor logs** for any suspicious activity
- **Regular credential rotation** recommended

## Troubleshooting

### Common Issues

1. **MT5 Connection Failed**:
   - Ensure MT5 terminal is running and logged in
   - Check login credentials and server name
   - Verify MT5 is not in demo mode (if needed)

2. **Tastytrade Connection Failed**:
   - Verify username/password
   - Check if account is active
   - Ensure API access is enabled

3. **Trades Not Copying**:
   - Check symbol mapping in config
   - Verify volume conversion logic
   - Review logs for specific error messages

### Debug Mode

Enable debug logging by setting `LOG_LEVEL=DEBUG` in your `.env` file.

## Production Considerations

- **Run as a service** using systemd, supervisor, or similar
- **Monitor system resources** (CPU, memory, network)
- **Set up alerts** for critical errors
- **Regular log rotation** and cleanup
- **Backup configuration** files

## Disclaimer

This software is for educational and informational purposes. Trading involves risk, and automated trading systems can amplify both gains and losses. Use at your own risk and ensure compliance with all applicable regulations.

## License

This project is provided as-is for educational purposes. Use responsibly and in accordance with your broker's terms of service.
