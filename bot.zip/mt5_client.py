"""
MetaTrader 5 client for copy trading system.
Handles connection, trade monitoring, and order detection.
"""
import MetaTrader5 as mt5
import time
from datetime import datetime
from typing import List, Dict, Optional, Tuple
from config import MT5_CONFIG
from utils.logger import logger

class MT5Client:
    """MetaTrader 5 client for trade monitoring and copying."""
    
    def __init__(self):
        self.connected = False
        self.last_trade_ticket = 0
        self.tracked_trades = set()  # Set of trade tickets already processed
        self.connection_attempts = 0
        self.max_connection_attempts = 5
    
    def connect(self) -> bool:
        """Connect to MetaTrader 5 terminal."""
        try:
            # Initialize MT5 with terminal path
            if not mt5.initialize(path=MT5_CONFIG['terminal_path']):
                logger.error(f"MT5 initialization failed: {mt5.last_error()}")
                return False
            
            # Check if already connected to an account
            account_info = mt5.account_info()
            if account_info is not None:
                # Already connected, use this account
                self.connected = True
                self.connection_attempts = 0
                logger.log_connection_status("MT5", "Connected", f"Account: {account_info.login} (Already connected)")
                
                # Initialize last trade ticket
                self._initialize_last_trade_ticket()
                return True
            else:
                # Not connected, try to login
                if not mt5.login(
                    login=MT5_CONFIG['login'],
                    password=MT5_CONFIG['password'],
                    server=MT5_CONFIG['server'],
                    timeout=MT5_CONFIG['timeout']
                ):
                    logger.error(f"MT5 login failed: {mt5.last_error()}")
                    mt5.shutdown()
                    return False
                
                # Get account info
                account_info = mt5.account_info()
                if account_info is None:
                    logger.error("Failed to get MT5 account info")
                    mt5.shutdown()
                    return False
                
                self.connected = True
                self.connection_attempts = 0
                logger.log_connection_status("MT5", "Connected", f"Account: {account_info.login}")
                
                # Initialize last trade ticket
                self._initialize_last_trade_ticket()
                
                return True
            
        except Exception as e:
            logger.error(f"MT5 connection error: {e}")
            return False
    
    def _initialize_last_trade_ticket(self):
        """Initialize the last trade ticket to avoid processing old trades."""
        try:
            # Get recent trades to find the latest ticket
            trades = mt5.history_deals_get(
                datetime.now().replace(hour=0, minute=0, second=0, microsecond=0),
                datetime.now()
            )
            if trades:
                self.last_trade_ticket = max(trade.ticket for trade in trades)
                logger.info(f"Initialized last trade ticket: {self.last_trade_ticket}")
        except Exception as e:
            logger.warning(f"Could not initialize last trade ticket: {e}")
    
    def disconnect(self):
        """Disconnect from MetaTrader 5."""
        if self.connected:
            mt5.shutdown()
            self.connected = False
            logger.log_connection_status("MT5", "Disconnected")
    
    def is_connected(self) -> bool:
        """Check if connected to MT5."""
        return self.connected and mt5.terminal_info() is not None
    
    def get_new_trades(self) -> List[Dict]:
        """Get new trades since last check."""
        if not self.is_connected():
            return []
        
        try:
            # Get all deals from today
            today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            deals = mt5.history_deals_get(today, datetime.now())
            
            if deals is None:
                return []
            
            new_trades = []
            for deal in deals:
                # Only process new trades (ticket > last_trade_ticket)
                if deal.ticket > self.last_trade_ticket and deal.ticket not in self.tracked_trades:
                    trade_info = self._parse_deal(deal)
                    if trade_info:
                        new_trades.append(trade_info)
                        self.tracked_trades.add(deal.ticket)
            
            # Update last trade ticket if we found new trades
            if new_trades:
                self.last_trade_ticket = max(trade['ticket'] for trade in new_trades)
            
            return new_trades
            
        except Exception as e:
            logger.error(f"Error getting new trades: {e}")
            return []
    
    def _parse_deal(self, deal) -> Optional[Dict]:
        """Parse MT5 deal into standardized format."""
        try:
            # Only process market orders (buy/sell)
            if deal.type not in [mt5.DEAL_TYPE_BUY, mt5.DEAL_TYPE_SELL]:
                return None
            
            # Get symbol info
            symbol_info = mt5.symbol_info(deal.symbol)
            if symbol_info is None:
                logger.warning(f"Symbol info not found for {deal.symbol}")
                return None
            
            trade_info = {
                'ticket': deal.ticket,
                'symbol': deal.symbol,
                'type': 'BUY' if deal.type == mt5.DEAL_TYPE_BUY else 'SELL',
                'volume': deal.volume,
                'price': deal.price,
                'time': deal.time,
                'comment': deal.comment or '',
                'magic': deal.magic,
                'order': deal.order,
                'position_id': deal.position_id,
                'profit': deal.profit,
                'swap': deal.swap,
                'commission': deal.commission,
                'symbol_info': {
                    'digits': symbol_info.digits,
                    'point': symbol_info.point,
                    'trade_contract_size': symbol_info.trade_contract_size,
                }
            }
            
            return trade_info
            
        except Exception as e:
            logger.error(f"Error parsing deal {deal.ticket}: {e}")
            return None
    
    def get_positions(self) -> List[Dict]:
        """Get current open positions."""
        if not self.is_connected():
            return []
        
        try:
            positions = mt5.positions_get()
            if positions is None:
                return []
            
            return [self._parse_position(pos) for pos in positions]
            
        except Exception as e:
            logger.error(f"Error getting positions: {e}")
            return []
    
    def _parse_position(self, position) -> Dict:
        """Parse MT5 position into standardized format."""
        return {
            'ticket': position.ticket,
            'symbol': position.symbol,
            'type': 'BUY' if position.type == mt5.POSITION_TYPE_BUY else 'SELL',
            'volume': position.volume,
            'price_open': position.price_open,
            'price_current': position.price_current,
            'profit': position.profit,
            'swap': position.swap,
            'time': position.time,
            'magic': position.magic,
            'comment': position.comment or '',
        }
    
    def get_orders(self) -> List[Dict]:
        """Get current pending orders."""
        if not self.is_connected():
            return []
        
        try:
            orders = mt5.orders_get()
            if orders is None:
                return []
            
            return [self._parse_order(order) for order in orders]
            
        except Exception as e:
            logger.error(f"Error getting orders: {e}")
            return []
    
    def _parse_order(self, order) -> Dict:
        """Parse MT5 order into standardized format."""
        return {
            'ticket': order.ticket,
            'symbol': order.symbol,
            'type': 'BUY' if order.type == mt5.ORDER_TYPE_BUY else 'SELL',
            'volume': order.volume,
            'price_open': order.price_open,
            'price_current': order.price_current,
            'time_setup': order.time_setup,
            'time_done': order.time_done,
            'magic': order.magic,
            'comment': order.comment or '',
        }
    
    def health_check(self) -> bool:
        """Perform health check on MT5 connection."""
        try:
            if not self.is_connected():
                if self.connection_attempts < self.max_connection_attempts:
                    logger.warning("MT5 connection lost, attempting reconnection...")
                    self.connection_attempts += 1
                    return self.connect()
                else:
                    logger.critical("Max MT5 reconnection attempts reached")
                    return False
            
            # Reset connection attempts on successful health check
            self.connection_attempts = 0
            return True
            
        except Exception as e:
            logger.error(f"MT5 health check error: {e}")
            return False
