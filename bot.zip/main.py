#!/usr/bin/env python3
"""
Main script for MT5 to Tastytrade copy trading system.
Orchestrates the connection, monitoring, and trade copying process.
"""
import time
import signal
import sys
from typing import Dict, List
from config import COPY_TRADING_CONFIG
from mt5_client import MT5Client
from tasty_client import TastyClient
from utils.logger import logger

class CopyTradingSystem:
    """Main copy trading system orchestrator."""
    
    def __init__(self):
        self.mt5_client = MT5Client()
        self.tasty_client = TastyClient()
        self.running = False
        self.copied_trades = set()  # Track already copied trades
        self.cycle_count = 0
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown signals gracefully."""
        logger.info(f"Received signal {signum}, shutting down gracefully...")
        self.stop()
        sys.exit(0)
    
    def start(self) -> bool:
        """Start the copy trading system."""
        try:
            logger.log_system_start()
            
            # Connect to MT5
            logger.info("Connecting to MetaTrader 5...")
            if not self.mt5_client.connect():
                logger.error("Failed to connect to MT5. Exiting.")
                return False
            
            # Connect to Tastytrade (optional for testing)
            logger.info("Connecting to Tastytrade...")
            if not self.tasty_client.connect():
                logger.warning("Failed to connect to Tastytrade. Running in MT5-only mode for testing.")
                logger.info("System will monitor MT5 trades but won't copy them to Tastytrade.")
                # Continue without Tastytrade for testing
            else:
                logger.info("Both connections established successfully!")
            
            self.running = True
            
            # Start main loop
            self._main_loop()
            
            return True
            
        except Exception as e:
            logger.critical(f"Fatal error starting system: {e}")
            return False
    
    def stop(self):
        """Stop the copy trading system."""
        logger.info("Stopping copy trading system...")
        self.running = False
        
        # Disconnect clients
        if self.mt5_client:
            self.mt5_client.disconnect()
        
        if self.tasty_client:
            self.tasty_client.disconnect()
        
        logger.log_system_stop()
    
    def _main_loop(self):
        """Main monitoring and copying loop."""
        logger.info("Starting main copy trading loop...")
        
        while self.running:
            try:
                self.cycle_count += 1
                logger.debug(f"Starting cycle {self.cycle_count}")
                
                # Health checks
                if not self._perform_health_checks():
                    logger.error("Health checks failed, stopping system")
                    break
                
                # Check for new MT5 trades
                new_trades = self._check_new_trades()
                
                # Copy new trades to Tastytrade
                if new_trades:
                    self._copy_trades(new_trades)
                
                # Wait before next cycle
                time.sleep(COPY_TRADING_CONFIG['polling_interval'])
                
            except KeyboardInterrupt:
                logger.info("Keyboard interrupt received")
                break
            except Exception as e:
                logger.error(f"Error in main loop: {e}")
                time.sleep(COPY_TRADING_CONFIG['retry_delay'])
    
    def _perform_health_checks(self) -> bool:
        """Perform health checks on both connections."""
        try:
            # Check MT5 connection
            if not self.mt5_client.health_check():
                logger.error("MT5 health check failed")
                return False
            
            # Check Tastytrade connection only if connected
            if self.tasty_client.is_connected() and not self.tasty_client.health_check():
                logger.error("Tastytrade health check failed")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Health check error: {e}")
            return False
    
    def _check_new_trades(self) -> List[Dict]:
        """Check for new trades in MT5."""
        try:
            new_trades = self.mt5_client.get_new_trades()
            
            if new_trades:
                logger.info(f"Found {len(new_trades)} new trades in MT5")
                for trade in new_trades:
                    logger.log_trade_detected(trade)
            
            return new_trades
            
        except Exception as e:
            logger.error(f"Error checking new trades: {e}")
            return []
    
    def _copy_trades(self, trades: List[Dict]):
        """Copy trades from MT5 to Tastytrade."""
        for trade in trades:
            try:
                # Skip if already copied
                if trade['ticket'] in self.copied_trades:
                    logger.debug(f"Trade {trade['ticket']} already copied, skipping")
                    continue
                
                # Validate trade before copying
                if not self._validate_trade(trade):
                    logger.warning(f"Trade {trade['ticket']} validation failed, skipping")
                    continue
                
                # Check if Tastytrade is connected
                if not self.tasty_client.is_connected():
                    logger.info(f"MT5 trade detected but Tastytrade not connected: {trade['symbol']} {trade['type']} {trade['volume']} lots")
                    # Mark as "copied" to avoid reprocessing, but note it wasn't actually copied
                    self.copied_trades.add(trade['ticket'])
                    continue
                
                # Place order in Tastytrade
                logger.info(f"Copying trade {trade['ticket']} to Tastytrade...")
                tasty_order = self.tasty_client.place_order(trade)
                
                if tasty_order:
                    # Mark as copied
                    self.copied_trades.add(trade['ticket'])
                    logger.log_trade_copied(trade, tasty_order)
                    
                    # Log success details
                    logger.info(
                        f"Successfully copied: {trade['symbol']} {trade['type']} "
                        f"{trade['volume']} lots -> {tasty_order['quantity']} shares"
                    )
                else:
                    logger.log_copy_error(trade, "Failed to place order in Tastytrade")
                
            except Exception as e:
                logger.log_copy_error(trade, str(e))
    
    def _validate_trade(self, trade: Dict) -> bool:
        """Validate trade before copying."""
        try:
            # Check required fields
            required_fields = ['ticket', 'symbol', 'type', 'volume']
            for field in required_fields:
                if field not in trade or trade[field] is None:
                    logger.warning(f"Trade missing required field: {field}")
                    return False
            
            # Validate order type
            if trade['type'] not in ['BUY', 'SELL']:
                logger.warning(f"Invalid order type: {trade['type']}")
                return False
            
            # Validate volume
            if trade['volume'] <= 0:
                logger.warning(f"Invalid volume: {trade['volume']}")
                return False
            
            # Validate symbol (basic check)
            if not trade['symbol'] or len(trade['symbol']) == 0:
                logger.warning("Invalid symbol")
                return False
            
            return True
            
        except Exception as e:
            logger.error(f"Trade validation error: {e}")
            return False
    
    def get_status(self) -> Dict:
        """Get current system status."""
        return {
            'running': self.running,
            'cycle_count': self.cycle_count,
            'mt5_connected': self.mt5_client.is_connected(),
            'tasty_connected': self.tasty_client.is_connected(),
            'copied_trades_count': len(self.copied_trades),
            'mt5_positions': len(self.mt5_client.get_positions()),
            'tasty_positions': len(self.tasty_client.get_positions()),
        }

def main():
    """Main entry point."""
    try:
        # Create and start copy trading system
        system = CopyTradingSystem()
        
        # Start the system
        if not system.start():
            logger.critical("Failed to start copy trading system")
            sys.exit(1)
        
    except Exception as e:
        logger.critical(f"Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
