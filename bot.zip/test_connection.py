#!/usr/bin/env python3
"""
Test script to verify connections to MT5 and Tastytrade.
Use this to test your credentials before running the full copy trading system.
"""
import sys
from mt5_client import MT5Client
from tasty_client import TastyClient
from utils.logger import logger

def test_mt5_connection():
    """Test MT5 connection."""
    print("Testing MT5 connection...")
    mt5_client = MT5Client()
    
    try:
        if mt5_client.connect():
            print("✅ MT5 connection successful!")
            
            # Test getting positions
            positions = mt5_client.get_positions()
            print(f"   Current positions: {len(positions)}")
            
            # Test getting orders
            orders = mt5_client.get_orders()
            print(f"   Current orders: {len(orders)}")
            
            mt5_client.disconnect()
            return True
        else:
            print("❌ MT5 connection failed!")
            return False
            
    except Exception as e:
        print(f"❌ MT5 connection error: {e}")
        return False

def test_tasty_connection():
    """Test Tastytrade connection."""
    print("Testing Tastytrade connection...")
    tasty_client = TastyClient()
    
    try:
        if tasty_client.connect():
            print("✅ Tastytrade connection successful!")
            
            # Test getting positions
            positions = tasty_client.get_positions()
            print(f"   Current positions: {len(positions)}")
            
            # Test getting orders
            orders = tasty_client.get_orders()
            print(f"   Current orders: {len(orders)}")
            
            tasty_client.disconnect()
            return True
        else:
            print("❌ Tastytrade connection failed!")
            return False
            
    except Exception as e:
        print(f"❌ Tastytrade connection error: {e}")
        return False

def main():
    """Main test function."""
    print("=== Connection Test for Copy Trading System ===\n")
    
    mt5_success = test_mt5_connection()
    print()
    
    tasty_success = test_tasty_connection()
    print()
    
    if mt5_success and tasty_success:
        print("🎉 All connections successful! You can now run the copy trading system.")
        print("Run: python main.py")
    else:
        print("❌ Some connections failed. Please check your credentials and try again.")
        if not mt5_success:
            print("   - Verify MT5 terminal is running and credentials are correct")
        if not tasty_success:
            print("   - Verify Tastytrade credentials and account status")
        sys.exit(1)

if __name__ == "__main__":
    main()
