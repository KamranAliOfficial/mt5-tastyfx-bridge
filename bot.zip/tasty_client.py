"""
Tastytrade client for copy trading system.
Handles connection, order placement, and position management.
"""
import time
from typing import List, Dict, Optional
from tastytrade.session import Session
from tastytrade.order import NewOrder, OrderType, OrderAction, OrderTimeInForce
from config import TASTY_CONFIG, SYMBOL_MAPPING
from utils.logger import logger

class TastyClient:
    """Tastytrade client for order execution and position management."""
    
    def __init__(self):
        self.session = None
        self.connected = False
        self.account = None
        self.connection_attempts = 0
        self.max_connection_attempts = 5
        self.orders_cache = {}  # Cache of placed orders for tracking
    
    def connect(self) -> bool:
        """Connect to Tastytrade API."""
        try:
            # Create session
            self.session = Session(
                login=TASTY_CONFIG['username'],
                password=TASTY_CONFIG['password'],
                is_test=TASTY_CONFIG['is_test']
            )
            
            # Get account info
            accounts = self.session.get_accounts()
            if not accounts:
                logger.error("No Tastytrade accounts found")
                return False
            
            # Use first account (can be modified to use specific account)
            self.account = accounts[0]
            self.connected = True
            self.connection_attempts = 0
            
            logger.log_connection_status(
                "Tastytrade", 
                "Connected", 
                f"Account: {self.account.account_number} ({'Sandbox' if TASTY_CONFIG['is_test'] else 'Live'})"
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Tastytrade connection error: {e}")
            return False
    
    def disconnect(self):
        """Disconnect from Tastytrade API."""
        if self.session:
            try:
                self.session.destroy()
            except:
                pass
        self.session = None
        self.connected = False
        self.account = None
        logger.log_connection_status("Tastytrade", "Disconnected")
    
    def is_connected(self) -> bool:
        """Check if connected to Tastytrade."""
        return self.connected and self.session is not None and self.account is not None
    
    def place_order(self, mt5_trade: Dict) -> Optional[Dict]:
        """Place an order in Tastytrade based on MT5 trade."""
        if not self.is_connected():
            logger.error("Cannot place order: not connected to Tastytrade")
            return None
        
        try:
            # Map MT5 symbol to Tastytrade symbol
            symbol = self._map_symbol(mt5_trade['symbol'])
            if not symbol:
                logger.error(f"Symbol mapping not found for {mt5_trade['symbol']}")
                return None
            
            # Map MT5 order type to Tastytrade order action
            order_action = self._map_order_action(mt5_trade['type'])
            if not order_action:
                logger.error(f"Order action mapping not found for {mt5_trade['type']}")
                return None
            
            # Calculate quantity (convert MT5 volume to Tastytrade quantity)
            quantity = self._calculate_quantity(mt5_trade['volume'], mt5_trade.get('symbol_info', {}))
            
            # Create order using new API
            order = NewOrder(
                symbol=symbol,
                action=order_action,
                quantity=quantity,
                order_type=OrderType.MARKET,
                time_in_force=OrderTimeInForce.DAY
            )
            
            # Place order
            logger.info(f"Placing order in Tastytrade: {symbol} {order_action} {quantity}")
            result = self.account.place_order(order)
            
            if result:
                order_info = {
                    'order_id': result.order_id,
                    'symbol': symbol,
                    'action': order_action.value,
                    'quantity': quantity,
                    'status': result.status,
                    'mt5_ticket': mt5_trade['ticket'],
                    'timestamp': time.time()
                }
                
                # Cache the order for tracking
                self.orders_cache[result.order_id] = order_info
                
                logger.info(f"Order placed successfully: {order_info}")
                return order_info
            else:
                logger.error("Failed to place order in Tastytrade")
                return None
                
        except Exception as e:
            logger.error(f"Error placing order: {e}")
            return None
    
    def _map_symbol(self, mt5_symbol: str) -> Optional[str]:
        """Map MT5 symbol to Tastytrade symbol."""
        # Check custom mapping first
        if mt5_symbol in SYMBOL_MAPPING:
            return SYMBOL_MAPPING[mt5_symbol]
        
        # For now, assume same symbol names
        # You can add custom logic here for different symbol formats
        return mt5_symbol
    
    def _map_order_action(self, mt5_order_type: str) -> Optional[OrderAction]:
        """Map MT5 order type to Tastytrade order action."""
        if mt5_order_type == 'BUY':
            return OrderAction.BUY_TO_OPEN
        elif mt5_order_type == 'SELL':
            return OrderAction.SELL_TO_OPEN
        else:
            return None
    
    def _calculate_quantity(self, mt5_volume: float, symbol_info: Dict) -> int:
        """Calculate Tastytrade quantity from MT5 volume."""
        try:
            # MT5 volume is typically in lots (0.01 = 1 lot)
            # Tastytrade uses whole shares
            # This is a simplified conversion - adjust based on your needs
            
            # If we have contract size info, use it
            if symbol_info.get('trade_contract_size'):
                contract_size = symbol_info['trade_contract_size']
                quantity = int(mt5_volume * contract_size)
            else:
                # Default conversion: assume 1 lot = 100 shares
                quantity = int(mt5_volume * 100)
            
            # Ensure minimum quantity of 1
            return max(1, quantity)
            
        except Exception as e:
            logger.warning(f"Error calculating quantity, using default: {e}")
            return int(mt5_volume * 100)
    
    def get_positions(self) -> List[Dict]:
        """Get current open positions."""
        if not self.is_connected():
            return []
        
        try:
            positions = self.account.get_positions()
            return [self._parse_position(pos) for pos in positions]
            
        except Exception as e:
            logger.error(f"Error getting positions: {e}")
            return []
    
    def _parse_position(self, position) -> Dict:
        """Parse Tastytrade position into standardized format."""
        return {
            'symbol': position.instrument.symbol,
            'quantity': position.quantity,
            'side': position.side.value,
            'average_price': float(position.average_price),
            'market_value': float(position.market_value),
            'unrealized_gain_loss': float(position.unrealized_gain_loss),
            'realized_gain_loss': float(position.realized_gain_loss),
        }
    
    def get_orders(self) -> List[Dict]:
        """Get current orders (pending, filled, cancelled)."""
        if not self.is_connected():
            return []
        
        try:
            orders = self.account.get_orders()
            return [self._parse_order(order) for order in orders]
            
        except Exception as e:
            logger.error(f"Error getting orders: {e}")
            return []
    
    def _parse_order(self, order) -> Dict:
        """Parse Tastytrade order into standardized format."""
        return {
            'order_id': order.order_id,
            'symbol': order.instrument.symbol,
            'side': order.side.value,
            'quantity': order.quantity,
            'order_type': order.order_type.value,
            'status': order.status,
            'time_in_force': order.time_in_force.value,
            'created_at': order.created_at.isoformat() if order.created_at else None,
        }
    
    def get_order_status(self, order_id: str) -> Optional[str]:
        """Get status of a specific order."""
        try:
            orders = self.account.get_orders()
            for order in orders:
                if order.order_id == order_id:
                    return order.status
            return None
        except Exception as e:
            logger.error(f"Error getting order status: {e}")
            return None
    
    def cancel_order(self, order_id: str) -> bool:
        """Cancel a pending order."""
        if not self.is_connected():
            return False
        
        try:
            result = self.account.cancel_order(order_id)
            if result:
                logger.info(f"Order {order_id} cancelled successfully")
                return True
            else:
                logger.error(f"Failed to cancel order {order_id}")
                return False
                
        except Exception as e:
            logger.error(f"Error cancelling order {order_id}: {e}")
            return False
    
    def health_check(self) -> bool:
        """Perform health check on Tastytrade connection."""
        try:
            if not self.is_connected():
                if self.connection_attempts < self.max_connection_attempts:
                    logger.warning("Tastytrade connection lost, attempting reconnection...")
                    self.connection_attempts += 1
                    return self.connect()
                else:
                    logger.critical("Max Tastytrade reconnection attempts reached")
                    return False
            
            # Test connection by getting account info
            try:
                self.account.get_positions()
                self.connection_attempts = 0
                return True
            except:
                logger.warning("Tastytrade connection test failed")
                return False
            
        except Exception as e:
            logger.error(f"Tastytrade health check error: {e}")
            return False
